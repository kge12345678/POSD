#ifndef UT_FS_H
#define UT_FS_H

#include <sys/stat.h>
#include "../src/folder.h"
#include "../src/file.h"
#include "../src/info_content_visitor.h"
#include "../src/find_visitor.h"
#include "../src/node_builder.h"
#include "../src/link.h"
#include "../src/find_link_visitor.h"
#include "../src/find_node_by_pathname_visitor.h"

TEST(MisTest, lstatOnFolder){
  const char * path = "./test_data";
  struct stat st;
  ASSERT_EQ(0, lstat(path, &st));
  ASSERT_EQ(4096, st.st_size);
  ASSERT_EQ(true, S_ISDIR(st.st_mode));
  ASSERT_EQ(false, S_ISREG(st.st_mode));
  ASSERT_EQ(false, S_ISLNK(st.st_mode));
}

TEST(Test, NodeBuilder){
  NodeBuilder nb;
  //nb.build("makefile");
  //ASSERT_EQ(1001, nb.getRoot()->size());
  nb.build("test_data/hello.cpp");
  ASSERT_EQ(83, nb.getRoot()->size());
  nb.build("test_data/hello");
  ASSERT_EQ(12, nb.getRoot()->size());
  nb.build("test_data/folder");
  ASSERT_EQ(4096, nb.getRoot()->size());
  NodeIterator * it = nb.getRoot()->createIterator();
  it->first();
  //ASSERT_TRUE(it->isDone());
  ASSERT_EQ(8432, it->currentItem()->size());
  it->next();
  ASSERT_TRUE(it->isDone());

  nb.build("test_data");
  ASSERT_EQ(4096, nb.getRoot()->size());
  NodeIterator * it1 = nb.getRoot()->createIterator();
  it1->first();
  ASSERT_EQ(4096, it1->currentItem()->size());
  it1->next();
  ASSERT_EQ(12, it1->currentItem()->size());
  it1->next();
  ASSERT_EQ(83, it1->currentItem()->size());
  it1->next();
  //ASSERT_TRUE(it1->isDone());
}

TEST(Test, file_size){
  Node * test_data = new Folder("./test_data");
  Node * folder = new Folder("./test_data/folder");
  Node * hello_cpp = new File("./test_data/hello.cpp");
  Node * a_out = new File("./test_data/folder/a.out");
  Node * hello = new Link("./test_data/hello", a_out);
  folder->add(a_out);//8432
  test_data->add(folder);
  test_data->add(hello);//8432
  test_data->add(hello_cpp);//83
  ASSERT_EQ(4096,test_data->size());
  ASSERT_EQ(4096, folder->size());
  ASSERT_EQ(83, hello_cpp->size());
  ASSERT_EQ(8432, a_out->size());
  ASSERT_EQ(12, hello->size());
  ASSERT_EQ(8432, hello->getSource()->size());
  ASSERT_EQ(3, test_data->numberOfChildren());
}

TEST(Test, test_data){
  Node * test_data = new Folder("./test_data");
  Node * folder = new Folder("./test_data/folder");
  Node * hello_cpp = new File("./test_data/hello.cpp");
  Node * a_out = new File("./test_data/folder/a.out");
  Node * hello = new Link("./test_data/hello", a_out);
  folder->add(a_out);//8432
  test_data->add(folder);
  test_data->add(hello);//8432
  test_data->add(hello_cpp);//83
  InfoContentVisitor * icv = new InfoContentVisitor();
  a_out->accept(icv);
  ASSERT_EQ(8432, icv->getContentSize());
  delete icv;
  InfoContentVisitor * icv1 = new InfoContentVisitor();
  hello->accept(icv1);
  ASSERT_EQ(8432,icv1->getContentSize());
  InfoContentVisitor * icv2 = new InfoContentVisitor();
  folder->accept(icv2);
  ASSERT_EQ(8432, icv2->getContentSize());
  InfoContentVisitor * icv3 = new InfoContentVisitor();
  test_data->accept(icv3);
  ASSERT_EQ(16947,icv3->getContentSize());
}

TEST (Test, NodeIterator){
  Node * test_data = new Folder("./test_data");
  Node * folder = new Folder("./test_data/folder");
  Node * hello_cpp = new File("./test_data/hello.cpp");
  Node * a_out = new File("./test_data/folder/a.out");
  Node * hello = new Link("./test_data/hello", a_out);
  folder->add(a_out);//8432
  test_data->add(folder);
  test_data->add(hello);//8432
  test_data->add(hello_cpp);//83
  NodeIterator * it = test_data->createIterator();
  it->first();
  ASSERT_EQ(4096, it->currentItem()->size());
  it->next();
  ASSERT_EQ(12, it->currentItem()->size());
  it->next();
  ASSERT_EQ(83, it->currentItem()->size());
  it->next();
  ASSERT_TRUE(it->isDone());
  ASSERT_ANY_THROW(it->currentItem());
  ASSERT_ANY_THROW(it->next());
  FindLinkVisitor *flv = new FindLinkVisitor();
  test_data->accept(flv);
  ASSERT_EQ(1, flv->getLinks().size());
}

TEST (FileSystemTest, NodeTypeError)
{
  ASSERT_ANY_THROW(new File("./test_data/folder"));//Do not indicate the file path.
  ASSERT_ANY_THROW(new Folder("./test_data/hello"));//Do not indicate the Folder path.
  ASSERT_ANY_THROW(new Link("./test_data/hello.cpp"));//Do not indicate the Link path.
}

TEST(FindLinkVisitor, visitFolder){
  Node * test_data = new Folder("./test_data");
  Node * folder = new Folder("./test_data/folder");
  Node * hello_cpp = new File("./test_data/hello.cpp");
  Node * a_out = new File("./test_data/folder/a.out");
  Node * hello = new Link("./test_data/hello", a_out);
  Node * test = new Link("./test_data/link_test/test", hello_cpp);
  Node * link_test = new Folder("./test_data/link_test");
  folder->add(a_out);//8432
  test_data->add(folder);
  test_data->add(hello);//8432
  test_data->add(hello_cpp);//83
  test_data->add(link_test);
  link_test->add(test);
  FindLinkVisitor *flv = new FindLinkVisitor();
  test_data->accept(flv);
  NodeIterator *it = flv->createIterator();
  ASSERT_EQ(2, flv->getLinks().size());
  hello->accept(flv);
  ASSERT_EQ(1, flv->getLinks().size());
  link_test->accept(flv);
  ASSERT_EQ(1, flv->getLinks().size());
  folder->accept(flv);
  ASSERT_EQ(0, flv->getLinks().size());
}

TEST (FindNodeByPathnameVisitor, Link){
  Node * test_data = new Folder("./test_data");
  Node * hello = new Link("./test_data/hello");
  vector<string>* names = new vector<string>{string("hello")};
  FindNodeByPathnameVisitor *fv = new FindNodeByPathnameVisitor(names);
  hello->accept(fv);
  ASSERT_EQ(hello, fv->getNode());
}

TEST (FindNodeByPathnameVisitor, LinkInFolder){
  Node * test_data = new Folder ("./test_data");
  Node * hello = new Link("./test_data/hello");
  test_data->add(hello);
  vector<string>* names = new vector<string>{string("test_data"), string("hello")};
  FindNodeByPathnameVisitor *fv = new FindNodeByPathnameVisitor(names);
  test_data->accept(fv);
  ASSERT_EQ(hello, fv->getNode());
}

TEST (FindNodeByPathnameVisitor, nonExistingFileInFileSystem){
  Node * test_data = new Folder ("./test_data");
  vector<string>* names = new vector<string>{string("test_data"), string("helloWorld")};
  FindNodeByPathnameVisitor *fv = new FindNodeByPathnameVisitor(names);
  test_data->accept(fv);
  ASSERT_EQ(nullptr, fv->getNode());
}

TEST (FindNodeByPathnameVisitor, fileInFolder){
  Node * test_data = new Folder ("./test_data");
  Node * hello_cpp = new File("./test_data/hello.cpp");
  test_data->add(hello_cpp);
  vector<string>* names = new vector<string>{string("test_data"), string("hello.cpp")};
  FindNodeByPathnameVisitor *fv = new FindNodeByPathnameVisitor(names);
  test_data->accept(fv);
  ASSERT_EQ(hello_cpp, fv->getNode());
  hello_cpp->accept(fv);
  ASSERT_EQ(nullptr, fv->getNode());
}

TEST (FindNodeByPathnameVisitor, folder){
  Node * test_data = new Folder ("./test_data");
  Node * folder = new Folder("./test_data/folder");
  Node * a_out = new File("./test_data/folder/a.out");
  test_data->add(folder);
  folder->add(a_out);
  vector<string>* names = new vector<string>{string("test_data"), string("folder"), string("a.out")};
  FindNodeByPathnameVisitor *fv = new FindNodeByPathnameVisitor(names);
  test_data->accept(fv);
  ASSERT_EQ(a_out, fv->getNode());
  folder->accept(fv);
  ASSERT_EQ(nullptr, fv->getNode());
  test_data->accept(fv);
  ASSERT_EQ(a_out, fv->getNode());
  a_out->accept(fv);
  ASSERT_EQ(nullptr, fv->getNode());
}

TEST (FindNodeByPathnameVisitor, FindFolder){
  Node * test_data = new Folder ("./test_data");
  vector<string>* names = new vector<string>{string("test_data")};
  FindNodeByPathnameVisitor *fv = new FindNodeByPathnameVisitor(names);
  test_data->accept(fv);
  ASSERT_EQ(test_data, fv->getNode());
}

TEST (FindNodeByPathnameVisitor, FindFolderInFolder){
  Node * test_data = new Folder ("./test_data");
  Node * folder = new Folder("./test_data/folder");
  test_data->add(folder);
  vector<string>* names = new vector<string>{string("test_data"), string("folder")};
  FindNodeByPathnameVisitor *fv = new FindNodeByPathnameVisitor(names);
  test_data->accept(fv);
  ASSERT_EQ(folder, fv->getNode());
}

#endif
