#include "find_node_by_pathname_visitor.h"
#include "node.h"
#include "folder.h"
#include "file.h"
#include "link.h"
#include <vector>
#include <string>
#include <iterator>
#include <iostream>
using namespace std;

FindNodeByPathnameVisitor::FindNodeByPathnameVisitor(vector<string>* pathnames):_node(nullptr), _pathnames(pathnames){
  _it = _pathnames->begin();
}

void FindNodeByPathnameVisitor::visitFolder(Folder * folder){
  if(_it != _pathnames->end()){
    if((*_it).compare(folder->name()) == 0){
      if(_it + 1 != _pathnames->end()){
        _it++;
        NodeIterator *folderIterator = folder->createIterator();
        for(folderIterator->first(); !folderIterator->isDone(); folderIterator->next()){
          folderIterator->currentItem()->accept(this);
        }
      }
      else{
        //cout << "test" << endl;
        _node = folder;
      }
    }
  }
}

void FindNodeByPathnameVisitor::visitFile(File * file){
  if(_it != _pathnames->end()){
    if((*_it).compare(file->name()) == 0){
      _node = file;
    }
  }
}

void FindNodeByPathnameVisitor::visitLink(Link * link){
  if(_it != _pathnames->end()){
    if((*_it).compare(link->name()) == 0){
      _node = link;
    }
  }
}

Node * FindNodeByPathnameVisitor::getNode(){
  Node *temp = _node;
  _node = nullptr;
  _it = _pathnames->begin();
  return temp;
}
