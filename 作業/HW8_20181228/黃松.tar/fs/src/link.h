#ifndef LINK_H
#define LINK_H

#include "node.h"
#include "node_visitor.h"

class Link: public Node{
  public:
    Link(const char * path, Node * node = nullptr):Node(path){
      struct stat st;
      lstat(path, &st);
      if(S_ISLNK(st.st_mode) == 0){
        throw string("Type Error");
      }
      addLink(node);
    }

    void accept(NodeVisitor * icv){
      icv->visitLink(this);
    }

    void addLink(Node * node){
      _source = node;
    }

    Node * getSource() {
      return _source;
    }

    int numberOfChildren() const{
      return -1;
    }

  private:
    Node * _source;
};

#endif
