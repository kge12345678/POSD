#ifndef HELLO_WORLD_H
#define HELLO_WORLD_H

#include <wx/treectrl.h>

class HelloWorldApp : public wxApp
{
public:
	virtual bool OnInit();
  wxTreeCtrl *_tree;
};

DECLARE_APP(HelloWorldApp)

#endif // INCLUDED_HELLOWORLDAPP_H
