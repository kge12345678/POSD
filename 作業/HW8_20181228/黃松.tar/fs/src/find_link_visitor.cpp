#include "find_link_visitor.h"
#include "folder.h"
#include "file.h"
#include "link.h"

FindLinkVisitor::FindLinkVisitor(){
  _links.clear();
}

void FindLinkVisitor::visitFile(File *file){

}

void FindLinkVisitor::visitFolder(Folder *folder){
  NodeIterator *it = folder->createIterator();
  for(it->first(); !it->isDone(); it->next()){
    if(it->currentItem()->numberOfChildren() > 0){
      FindLinkVisitor *subFlv = new FindLinkVisitor();
      it->currentItem()->accept(subFlv);
      NodeIterator *subLinks = subFlv->createIterator();
      for(subLinks->first(); !subLinks->isDone(); subLinks->next()){
        _links.push_back(subLinks->currentItem());
      }
    }
    else if(it->currentItem()->numberOfChildren() == -1){
      _links.push_back(it->currentItem());
    }
  }
}

void FindLinkVisitor::visitLink(Link *link){
  _links.push_back(link);
}

vector<Node*>FindLinkVisitor::getLinks(){
  vector<Node*> temp = _links;
  _links.clear();
  return temp;
}
