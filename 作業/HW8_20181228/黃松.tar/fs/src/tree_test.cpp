#include <wx/wx.h>
#include "tree_test.h"
#include "tree_frame.h"

IMPLEMENT_APP(TreeTestApp)

bool TreeTestApp::OnInit()
{
  wxFrame *treeFrame = new TreeFrame(wxT("***Tree Test***"), 100,100,300,200);
  treeFrame->Show(true);
  this->SetTopWindow(treeFrame);
  return true;
}
