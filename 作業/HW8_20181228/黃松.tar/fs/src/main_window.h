#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include <wx/treectrl.h>
#include <wx/button.h>

#include "node.h"
#include "node_builder.h"

class MainWindow : public wxApp
{
public:
	MainWindow();
	virtual bool OnInit();
	void setTreeCtrl(NodeBuilder *nb);
  wxTreeCtrl *_tree;
	wxTextCtrl *_text;
	wxButton *_saveButton;
};

DECLARE_APP(MainWindow)

#endif // INCLUDED_HELLOWORLDAPP_H
