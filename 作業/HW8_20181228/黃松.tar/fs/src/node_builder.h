#ifndef NODE_BUILDER_H
#define NODE_BUILDER_H
#include <wx/treectrl.h>
#include <string>
#include <sys/stat.h>
#include <dirent.h>
#include <iostream>
#include "link.h"
#include "node.h"
#include "file.h"
#include "folder.h"

using namespace std;

class NodeBuilder{
  public:
    NodeBuilder(wxTreeCtrl *tree, wxTreeItemId treeRoot, wxTreeItemId folder):_tree(tree), _treeRoot(treeRoot), _folder(folder){

    }

    Node * getRoot(){
      return _root;
    }

    void build(const char * path){
      struct stat st;
      if(lstat(path, &st) == 0){
        if(S_ISREG(st.st_mode)){
          _root = new File(path);
          if(_treeRoot == nullptr){
            _treeRoot = _tree->AddRoot(wxString(_root->getNameAndSize()));
          }
          else{
            _tree->AppendItem(_folder, wxString(_root->getNameAndSize()));
          }
        }
        else if (S_ISLNK(st.st_mode)){
          _root = new Link(path);
          if(_treeRoot == nullptr){
            _treeRoot = _tree->AddRoot(wxString(_root->getNameAndSize()));
          }
          else{
            _tree->AppendItem(_folder, wxString(_root->getNameAndSize()));
          }
        }
        else if(S_ISDIR(st.st_mode)){
          _root = new Folder(path);
          if(_treeRoot == nullptr){
            _treeRoot = _tree->AddRoot(wxString(_root->getNameAndSize()));
            _folder = _treeRoot;
          }
          else{
            _folder = _tree->AppendItem(_folder, wxString(_root->getNameAndSize()));
          }
          DIR * dir = opendir(path);
          if (dir == nullptr){
            throw string("open folder error");
          }
          struct dirent * entry = nullptr;
          while((entry = readdir(dir)) != nullptr) {
            if (string(entry->d_name) != "." && string(entry->d_name) != "..") {
              NodeBuilder *nb = new NodeBuilder(_tree, _treeRoot, _folder);
              string pathName = string(path) + "/" + entry->d_name;
              nb->build(pathName.c_str());
              _root->add(nb->getRoot());
            }
          }
        }
      }
    }

    wxTreeCtrl * getTree(){
      return _tree;
    }

  private:
    Node * _root;
    wxTreeCtrl *_tree;
    wxTreeItemId _treeRoot;
    wxTreeItemId _folder;
};

#endif
