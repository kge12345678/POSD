#ifndef NODE_H
#define NODE_H
#include <sys/stat.h>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;
class NodeVisitor;
class NodeIterator;

class Node{
  public:
    Node(const char * path): _path(path){
      lstat(_path, &_st);
      int i;
      string tempPath(_path);
      for(i = tempPath.length();i >= 0;i--){
        if(_path[i] == '/'){
          break;
        }
      }
      _nodeName = tempPath.substr(i+1, tempPath.length());
      _parent = nullptr;
    }

    int size() const{
      return _st.st_size;
    }

    string name(){
      return _nodeName;
    }

    string getPath(){
      return string(_path);
    }

    string getNameAndSize(){
      return name() + ", " + to_string(size());
    }

    virtual void add(Node *node){
      throw string("unable to add");
    }

    virtual int numberOfChildren() const = 0;

    virtual void accept(NodeVisitor *nodeVisitor) = 0;

    virtual NodeIterator *createIterator(){}

    virtual Node* getSource(){
      return nullptr;
    }

    Node * getParent() const{
      return _parent;
    }
    void setParent (Node * p){
      _parent = p;
    }

  private:
    const char * _path;
    struct stat _st;
    string _nodeName;
    Node* _parent;
};

#endif
