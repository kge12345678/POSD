#ifndef FIND_NODE_BY_PATHNAME_VISITOR
#define FIND_NODE_BY_PATHNAME_VISITOR
#include "node_visitor.h"
#include <string>
#include <vector>
#include <iterator>
using namespace std;

class FindNodeByPathnameVisitor: public NodeVisitor{
  public:
    FindNodeByPathnameVisitor(vector<string>* pathnames);
    void visitFolder(Folder * folder);
    void visitFile(File * file);
    void visitLink(Link * link);
    Node * getNode();
  private:
    Node * _node;
    vector<string>::iterator _it;
    vector<string>* _pathnames;
};

#endif
