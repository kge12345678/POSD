
#ifndef _CONTAINERFRAME_H
#define _CONTAINERFRAME_H

#include <wx/treectrl.h>
#include "messages.h"

class ContainerFrame : public wxFrame
{
  public:
    ContainerFrame(const wxChar *title, int xpos, int ypos, int width, int height):wxFrame((wxFrame *) nullptr, -1, title, wxPoint(xpos, ypos), wxSize(width, height)){

    }

    void setTree(wxTreeCtrl *tree){
      _tree = tree;
    }

    void OnEdit(wxTreeEvent& event){
      _tree->EditLabel(event.GetItem());
      // Messages *editMessage = new Messages(wxT("Confirm"));
      // editMessage->ShowMessage3(event);
    }

    void OnEndEdit(wxTreeEvent& event){
      Messages *editMessage = new Messages(wxT("Confirm"));
      editMessage->ShowMessage3(event);
    }

    void OnClick(wxTreeEvent& event){
      cout << event.GetLabel().ToStdString() << endl;
    }

    wxTreeCtrl *_tree;

  private:
    DECLARE_EVENT_TABLE()
};

BEGIN_EVENT_TABLE(ContainerFrame, wxFrame)
  EVT_TREE_END_LABEL_EDIT (wxID_ANY, ContainerFrame::OnEndEdit)
  //EVT_TREE_KEY_DOWN (wxID_ANY, ContainerFrame::OnClick)
  EVT_TREE_SEL_CHANGED (wxID_ANY, ContainerFrame::OnClick)
  EVT_TREE_ITEM_ACTIVATED(wxID_ANY, ContainerFrame::OnEdit)
END_EVENT_TABLE()

#endif
