#ifndef FIND_LINK_VISITOR_H
#define FIND_LINK_VISITOR_H
#include "node_visitor.h"
#include <string>
using namespace std;

class FindLinkVisitor: public NodeVisitor{
  public:
    class FindLinkIterator: public NodeIterator{
      public:
        FindLinkIterator(FindLinkVisitor * flv):_flv(flv){

        }
        void first(){
          _it = _flv->_links.begin();
        }

        Node* currentItem(){
          if(isDone()){
            throw std::string("no current item");
          }
          return *_it;
        }

        void next(){
          if (isDone()){
            throw string("moving past the end");
          }
          if(!isDone()){
            _it++;
          }
        }

        bool isDone(){
          return _it == _flv->_links.end();
        }

      private:
        FindLinkVisitor *_flv;
        vector<Node*>::iterator _it;
    };
    FindLinkVisitor();
    void visitFolder(Folder * folder);
    void visitFile(File * file);
    void visitLink(Link * link);
    NodeIterator * createIterator(){
      return new FindLinkIterator(this);
    }
    vector<Node*> getLinks();//return the Link objects.
  private:
    vector<Node*> _links;
};

#endif
