#include <wx/wx.h>

#include "hello_world.h"
#include "text_frame.h"

IMPLEMENT_APP(HelloWorldApp)

// This is executed upon startup, like 'main()' in non-wxWidgets programs.
bool HelloWorldApp::OnInit()
{
	wxFrame *textFrame = new TextFrame(wxT("Hello wxWidgets World"), 200, 400, 400, 300);
	textFrame->Show(true);
	// wxFrame *treeFrame = new TreeFrame(wxT("***Tree Test***"), 100,100,300,200);
  // treeFrame->Show(true);
  // this->SetTopWindow(treeFrame);
	_tree = new wxTreeCtrl(textFrame, wxID_ANY, wxPoint(0,0), wxSize(100,200), wxTR_DEFAULT_STYLE | wxTR_SINGLE | wxTR_EDIT_LABELS );

	wxTreeItemId rootId = _tree->AddRoot(wxT("Root"));
	wxTreeItemId folder1Id = _tree->AppendItem(rootId, wxT("Folder1"));
	wxTreeItemId file1Id = _tree->AppendItem(folder1Id, wxT("File1"));
	wxTreeItemId file2Id = _tree->AppendItem(rootId, wxT("File2"));
	_tree->ExpandAllChildren(rootId);
	this->SetTopWindow(textFrame);
	
	return true;
}
