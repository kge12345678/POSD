#ifndef TREE_TEST_H
#define TREE_TEST_H

class TreeTestApp : public wxApp
{
public:
  virtual bool OnInit();

};

DECLARE_APP(TreeTestApp)

#endif
